<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="TX Tileset Ground" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../../../../Downloads/Pixel Art Platformer - Village Props v2.3.0/Texture/TX Tileset Ground.png" width="512" height="512"/>
</tileset>
