<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tiles_Village" tilewidth="32" tileheight="32" tilecount="26" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../assets/Tiles/000.png" width="32" height="32"/>
 </tile>
 <tile id="1">
  <image source="../assets/Tiles/001.png" width="32" height="32"/>
 </tile>
 <tile id="2">
  <image source="../assets/Tiles/002.png" width="32" height="32"/>
 </tile>
 <tile id="3">
  <image source="../assets/Tiles/003.png" width="32" height="32"/>
 </tile>
 <tile id="4">
  <image source="../assets/Tiles/004.png" width="32" height="32"/>
 </tile>
 <tile id="5">
  <image source="../assets/Tiles/005.png" width="32" height="32"/>
 </tile>
 <tile id="6">
  <image source="../assets/Tiles/006.png" width="32" height="32"/>
 </tile>
 <tile id="7">
  <image source="../assets/Tiles/007.png" width="32" height="32"/>
 </tile>
 <tile id="8">
  <image source="../assets/Tiles/008.png" width="32" height="32"/>
 </tile>
 <tile id="9">
  <image source="../assets/Tiles/009.png" width="32" height="32"/>
 </tile>
 <tile id="10">
  <image source="../assets/Tiles/010.png" width="32" height="32"/>
 </tile>
 <tile id="11">
  <image source="../assets/Tiles/011.png" width="32" height="32"/>
 </tile>
 <tile id="12">
  <image source="../assets/Tiles/012.png" width="32" height="32"/>
 </tile>
 <tile id="13">
  <image source="../assets/Tiles/013.png" width="32" height="32"/>
 </tile>
 <tile id="14">
  <image source="../assets/Tiles/014.png" width="32" height="32"/>
 </tile>
 <tile id="15">
  <image source="../assets/Tiles/015.png" width="32" height="32"/>
 </tile>
 <tile id="16">
  <image source="../assets/Tiles/016.png" width="32" height="32"/>
 </tile>
 <tile id="17">
  <image source="../assets/Tiles/017.png" width="32" height="32"/>
 </tile>
 <tile id="18">
  <image source="../assets/Tiles/018.png" width="32" height="32"/>
 </tile>
 <tile id="19">
  <image source="../assets/Tiles/019.png" width="32" height="32"/>
 </tile>
 <tile id="20">
  <image source="../assets/Tiles/020.png" width="32" height="32"/>
 </tile>
 <tile id="21">
  <image source="../assets/Tiles/021.png" width="32" height="32"/>
 </tile>
 <tile id="22">
  <image source="../assets/Tiles/022.png" width="32" height="32"/>
 </tile>
 <tile id="23">
  <image source="../assets/Tiles/023.png" width="32" height="32"/>
 </tile>
 <tile id="24">
  <image source="../assets/Tiles/024.png" width="32" height="32"/>
 </tile>
 <tile id="25">
  <image source="../assets/Tiles/025.png" width="32" height="32"/>
 </tile>
</tileset>
